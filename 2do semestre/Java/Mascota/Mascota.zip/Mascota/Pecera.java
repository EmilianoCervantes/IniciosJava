//relaci�n de composici�n2
public class Pecera{
	public double tama�o=1;
	public String forma="redonda"; //forma=redonda, rectangular

	public String toString(){
		return "Tama�o: "+tama�o+"m"+", forma: "+forma;
	}
}