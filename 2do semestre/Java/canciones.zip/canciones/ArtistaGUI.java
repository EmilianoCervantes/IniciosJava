import javax.swing.*; //Controles de swing
import java.awt.*;	//Eventos y layouts
import java.awt.event.*;	//Manejadores de Eventos

public class ArtistaGUI extends JFrame{
	private JPanel pPrincipal, pBotones, pCentral, pDatos;
	private JTextField txtNombre, txtNacionalidad, txtEdad;
	private JCheckBox cbSolista;
	private JList lbArtistas; 
	//Cada que uso una lista tengo que utilizar un modelo
	private DefaultListModel  modeloArtistas;
	private JButton bttnAgregar, bttnBorrar, bttnSalvar;
	
	public static void main(String[]args){
		new ArtistaGUI().setVisible(true);
	}
	
	public ArtistaGUI(){
		inicializarComponentes();
	}
	
	private void 	inicializarComponentes(){
		setSize(600,400);
		setTitle("Administración de Artistas");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//------------------------------------------------------------//
		//comenzamos con el primer panel
		pDatos= new JPanel(new GridLayout(4,2,10,10)); //El 10 significa la separación. 4 y 2 son renglones y columnas
		
		pDatos.add(new JLabel("Nombre: "));
		txtNombre= new JTextField();
		pDatos.add(txtNombre);
		
		pDatos.add(new JLabel("Nacionalidad: "));
		txtNacionalidad= new JTextField();
		pDatos.add(txtNacionalidad);
		
		pDatos.add(new JLabel("Edad: "));
		txtEdad= new JTextField();
		pDatos.add(txtEdad);
		
		cbSolista= new JCheckBox("Solista");
		pDatos.add(cbSolista);
		
		//------------------------------------------------------------//
		/*creamos el segundo panel
		Será un panel central con los datos y la lista de artista*/
		pCentral= new JPanel(new FlowLayout());
		pCentral.add(pDatos);
		
		modeloArtistas = new DefaultListModel();
		lbArtistas = new JList(modeloArtistas);
		pCentral.add(new JScrollPane(lbArtistas));
		
		//------------------------------------------------------------//
		//Realizamos el tercer panel, el panel de botones
		pBotones= new JPanel(new FlowLayout());
		
		bttnAgregar= new JButton("Agregar");
		bttnAgregar.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent evt){
				bttnAgregarClick();
			}
		});
		pBotones.add(bttnAgregar);
		
		bttnBorrar= new JButton("Borrar");
		pBotones.add(bttnBorrar);
		
		bttnSalvar= new JButton("Salvar");
		pBotones.add(bttnSalvar);
		
		//------------------------------------------------------------//
		//Hacemos el útlimo Panel
		pPrincipal = new JPanel(new BorderLayout()); 
		//Cuando usas border layout, le dices donde tiene que poner cada cosa
		pPrincipal.add(pCentral, BorderLayout.CENTER);
		pPrincipal.add(pBotones, BorderLayout.PAGE_END);
		
		add(pPrincipal);
		
	}
	
		//------------------------------------------------------------//
		//Escribimos el método que llamamos más arriba
		private void bttnAgregarClick(){
			Artista a = new Artista();
			a.nombre = txtNombre.getText();
			a.nacionalidad = txtNacionalidad.getText();
			a.edad= Integer.parseInt(txtEdad.getText());
			a.solista= cbSolista.isSelected();
			
			modeloArtistas.addElement(a); //Lo agrega al modelo
			lbArtistas.updateUI(); //Actualiza la lista de la interfaz gráfica
			
			txtNombre.setText(" ");
			txtNacionalidad.setText(" ");
			txtEdad.setText(" ");
			cbSolista.setSelected(false);
		}
}
	