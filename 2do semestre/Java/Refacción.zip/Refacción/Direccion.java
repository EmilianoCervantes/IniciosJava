//Llamado por marca
//relaci�n de composici�n - marca
public class Direccion{
	String calle, ciudad, col, deleg;
	int num;

	public String toString(){
		return "Calle: "+calle+", N�m: "+", Ciudad: "+ciudad+", Colonia: "+col+
				", Delegaci�n: "+deleg;
	}
}