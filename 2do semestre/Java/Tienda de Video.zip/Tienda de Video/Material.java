public class Material{
	public String nombre;
	public int edadMin;

	public String toString(){
		return "Nombre: "+nombre+", edad m�nima: "+edadMin;
	}
}