public class Videoteca{
	public static void main(String[] args){
		ClienteGUI cliente = new ClienteGUI();
		cliente.ejecutar();
	}
}