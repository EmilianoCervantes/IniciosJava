public class Institucion extends Cliente{
	public Persona encargado;
}