public class Cliente{
	public String nombre, dir;
	public int id;

	public String toString(){
		return id+": "+nombre+", "+dir;
	}
}