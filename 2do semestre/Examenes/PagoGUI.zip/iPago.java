public interface iPago{
	public void agregarAdeudo(Adeudo a);
	//public Adeudo obtenerAdeudo();
}