public class Condomino extends Persona{
	private boolean adeudo;
	public Condomino(){

	}
	public String getNombre(String nombre){
		return nombre;
	}
	public String getDir(String dir){
		return dir;
	}
	public boolean Pago(boolean pago){
		return pago;
	}
}