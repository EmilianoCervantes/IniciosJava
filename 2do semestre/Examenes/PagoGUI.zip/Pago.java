public class Pago implements iPago{
	Condomino[][] condos= new Condomino[100][2];
	protected double pago;
	Adeudo a;

	public void agregarAdeudo(Adeudo a){

	}
	/*public Adeudo obtenerAdeudo(){
		return a;
	}*/
}