public class Persona{
	protected String nombre, dir;

	public Persona(){

	}
	public String getNombre(String nombre){
		return nombre;
	}
	public String getDir(String dir){
		return dir;
	}
}