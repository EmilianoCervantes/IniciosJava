public class TestAeropuerto{
	public static void main(String args[]){
		//A1-100, A2-1000, A3-10000
		A1=new Aeropuerto(100);
		A2=new Aeropuerto(1000);
		A3=new Aeropuerto(10000);
	}
}