public class Contacto{
	String nombre, apellido, direccion, telefono;
	public static int tipoFuncion;

	public Contacto(String n, String t){
		this.telefono = t;
		this.nombre = n;
		//this.apellido = a;
		//this.direccion = dir;
	}

	@Override
	public String toString(){
		return nombre + ": " + ": " +telefono;
	}

	@Override
	public int hashCode(){
		int h = 0;
		switch(tipoFuncion){
			case 1:
				h = nombre.hashCode();
				break;
			/*case 2:
				h = apellido.hashCode()*31;
				break;
			case 3:
				h = direccion.hashCode()*29;
				break;*/

			case 2:
				h = telefono.hashCode()*29;
                break;
		}
		return h;
	}

	public String getNom(){
		return nombre;
	}
	public void setNom(String n){
		this.nombre = n;
	}

	/*public String getAp(){
		return apellido;
	}
	public void setAp(String a){
		this.apellido = a;
	}*/

	public String getTel(){
		return telefono;
	}
	public void setTel(String t){
		this.telefono = t;
	}

	/*public String getDir(){
		return direccion;
	}
	public void setDir(String dir){
		this.direccion = dir;
	}*/
}