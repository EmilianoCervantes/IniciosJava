import javax.swing.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
public class GUIMain extends JFrame{

	private JLabel txtTitulo, ldeci;
	public JButton bAgregar, bModificar, bMostrar, bBuscar;
	private Color colorcito= new Color(140,80,255);
	private JPanel panel;
	public HashTable<Integer,CircularDoubleLinkedList<Contacto>> agenda =new HashTable(10);
	public CircularDoubleLinkedList<Contacto> lista = new CircularDoubleLinkedList();


	public static void main (String [] args){

		new GUIMain().setVisible(true);
	}
	public GUIMain(){
		Contacto.tipoFuncion=(Integer.parseInt(JOptionPane.showInputDialog("Escriba el n�mero del tipo de funci�n Hash que desea aplicar a esta agenda")));

		draw();
	}
	public void agregar(HashTable<Integer, CircularDoubleLinkedList<Contacto>> agenda,CircularDoubleLinkedList<Contacto> lista) {
		String nombre=JOptionPane.showInputDialog("Escriba el nombre ");
		String tel=JOptionPane.showInputDialog("Escriba el tel�fono ");
		Contacto contacto = new Contacto(nombre, tel);
		lista.addLast(contacto);
		agenda.put(contacto,lista);


	}
	public void modificar() {
		SimpleList<Contacto> llaves= agenda.keys();
		for(int i=0;i<llaves.size();i++){
			Contacto c = new Contacto(llaves.get(i).getNom(),llaves.get(i).getTel());
			String modificar=JOptionPane.showInputDialog("�A qui�n quieres modificar?");
			if(c.getNombre().equals(modificar.toString())){
				String nomN=JOptionPane.showInputDialog("�Cu�l ser� el nuevo nombre");
				c.setNom(nomN);
				String telN=JOptionPane.showInputDialog("�Cu�l ser� el nuevo tel�fono");
				c.setTel(telN);
			}else{
				JOptionPane.showMessageDialog(frame, "No Encontrado");
			}
		}
	}
	public boolean buscar(){
		SimpleList<Contacto> llaves = agenda.keys();
		for(int i=0;i<llaves.size();i++){
			Contacto c = new Contacto(llaves.get(i).getNom(),llaves.get(i).getTel());
			String busqueda=JOptionPane.showInputDialog("�A qui�n buscas?");
			if(actual.getNom().equals(busqueda.toString()){
				JOptionPane.showMessageDialog(frame, "Encontrado");
				//JOptionPane.showMessageDialog(frame, c.getNom());
				JOptionPane.showMessageDialog(frame, c.getTel());
				return true;
			}else{
				JOptionPane.showMessageDialog(frame, "No Encontrado");
				return false;
			}
		}
		return false;

	}
	public void borrar(){
		SimpleList<Contacto> llaves= contactos.keys();
		for(int i=0;i<llaves.size();i++){
			String eliminar=JOptionPane.showInputDialog("�A qui�n quieres eliminar?");
			Contacto c = new Contacto(llaves.get(i).getNom(),llaves.get(i).getTel());
			if(c.getNom().equals(eliminar){
				contactos.eliminar(c);
			}
		}
	}


	public void draw(){
		setSize(900,600);
		setTitle("Agenda");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setLayout(new GridLayout(8,1));

		getContentPane().setBackground(colorcito);
		txtTitulo= new JLabel("Bienvenido a la agenda");
		txtTitulo.setBackground(colorcito);
		add(txtTitulo);

		bAgregar=new JButton("Agregar");
		bBuscar=new JButton("Buscar");
		bModificar=new JButton("Modificar");
		bMostrar=new JButton("Mostrar todo");
		bBorrar=new JButton("Borrar");
		add(bAgregar);
		add(bBuscar);
		add(bModificar);
		add(bMostrar);
		add(bBorrar);


		bAgregar.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				agregar(agenda, lista);
			}
		});
		bMostrar.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JOptionPane.showMessageDialog(frame, agenda.toString());
			}
		});
		bModificar.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				modificar(agenda, new Contact);
			}
		});
		bBuscar.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				buscar();
			}
		});
		bBorrar.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				borrar();
			}
		});
	}



}
