import java.lang.reflect.*;

public class HashTable<K,D>{

	private Dato[] tabla;

	public HashTable(int size){
		tabla = (Dato[]) Array.newInstance(Dato.class,size);
	}

	public SimpleList<K> keys(){
		SimpleList<K> todas= new SimpleList<K>();
		for(Dato t: tabla){
			if(t !=null){
				todas.addLast(t.llave);
			}
		}
		return todas;
	}

	public boolean containsKey(K llave){
		for(Dato data:tabla){
			if(llave.equals(data.llave)){
				return true;
			}
		}
		return false;

	}

	private int hash(K llave){
		return Math.abs(llave.hashCode());//valor absoluto de lo que de
	}

	public void put(K llave, D dato){
		int indice = hash(llave) % tabla.length;
		tabla[indice]= new Dato(llave,dato);
	}

	public D get(K llave){
		int indice = hash(llave) % tabla.length;
		if(tabla[indice] != null){
			return tabla[indice].dato;
		}else{
			return null;
		}
	}

	public String toString(){
		StringBuffer buffer = new StringBuffer();
		for(Dato data: tabla){
			if(data != null){
				buffer.append(data.llave + " | "+ data.dato + "\n" );
			}else{
				buffer.append(data);
			}
		}
		return buffer.toString();
	}

	public void eliminar(K llave){
		int l= hash(llave) % tabla.length;
		tabla[l]=null;
	}


	private class Dato{ //clase privada dentro de la clase, clae dentro de una clase
		K llave; //si no especificamos tipo de dato por dafault es protected, entonces puedo manejarlo desde afuera
		D dato;

		public Dato(K k,D d){
			dato = d;
			llave = k;
		}
	}
}