public class Persona{
	String nombre;
	String apellido;
	String direccion;
	String telefono;
	public static int hashFunction;

	public Persona(String nombre, String apellido, String direccion,String telefono){
		this.nombre=nombre;
		this.apellido=apellido;
		this.direccion=direccion;
		this.telefono=telefono;
	}

    public String getNombre(){
        return nombre;
    }

    public void setNombre(String nombre){
        this.nombre = nombre;
    }

    public String getApellido(){
        return apellido;
    }

    public void setApellido(String apellido){
        this.apellido = apellido;
    }

    public String getDireccion(){
        return direccion;
    }

    public void setDireccion(String direccion){
        this.direccion = direccion;
    }

    public String getTelefono(){
        return telefono;
    }

    public void setTelefono(String telefono){
        this.telefono = telefono;
    }

    @Override
    public String toString(){
        return "NOMBRE: " + nombre + " APELLIDO: " + apellido + " DIRECCION: " + direccion + " TELEFONO: " + telefono + "\n";
    }

    @Override
    public int hashCode(){
        int h = 0;
        switch(hashFunction){
            case 1:
                h = nombre.hashCode();
                break;

            case 2:
                h = apellido.hashCode()*31;
                break;

            case 3:
                h = direccion.hashCode()*27;
                break;

            case 4:
                h = telefono.hashCode()*19;
                break;
        }
        return h;
    }
}