import java.util.*;

public class SimpleList<T> implements List<T>, Deque<T> {

        private Nodo<T> inicio;

        public SimpleList(){
            inicio = null;
        }


        @Override
        public int size() {

        	if(isEmpty()){
        		return 0;
        	}

        	int size = 1;

        	Nodo crawler = inicio;

        	while(crawler.getSiguiente() != null){
        		crawler = crawler.getSiguiente();
        		size++;
        	}

            return size;

        }

        @Override
        public boolean isEmpty() {
                // TODO Auto-generated method stub
                return inicio == null;
        }

        //Irvin Uriel Mundo Rivera
        @Override
        public boolean contains(Object o) {
		Nodo b=new Nodo(o);
		Nodo crawler= inicio;
		while(crawler!=null){
			if(crawler.getDato()==b.getDato()){
				return true;
			}else{
				crawler=crawler.getSiguiente();

			}

		}
		return false;
	}

        //David Alexis Zarate Trujillo
        @Override
        public T get(int index) {
                if(index < 0 || index >= size()){
                	throw new IndexOutOfBoundsException();
                }

                Nodo crawler = inicio;

                for(int i = 0; i < index; i++){
                	crawler = crawler.getSiguiente();
                }


                return (T)crawler.getDato();
        }

        //Alejandra Cuellar Gonzalez
        @Override
        public T set(int index, T element) {

			if(index<0||index>size()){
				throw new IndexOutOfBoundsException();
			}else{
				int i=0;
				Nodo crawler= inicio;

				while(i < index){
					crawler=crawler.getSiguiente();
					i++;
				}
				T anterior= (T)crawler.getDato();
				crawler.setDato(element);
				return anterior;
			}
		}

        //TODO


        //Irvin Uriel Mundo Rivera
        @Override
        public void add(int index, T element) {
                // TODO Auto-generated method stub

               int size = size();

               if((index < 0 || index > size)){
               		throw new IndexOutOfBoundsException();
               }
               else if(isEmpty()){
               		inicio = new Nodo(element);
               }
               else if(index == 0){
               		addFirst(element);
               }
               else{
               		Nodo crawler = inicio;
               		for(int i = 0; i < index-1; i++){
               			crawler = crawler.getSiguiente();
               		}
               		Nodo nodo = new Nodo(element);
               		nodo.setSiguiente(crawler.getSiguiente());

               		crawler.setSiguiente(nodo);
               }
        }


		//Ethan Avila Hernandez
        @Override
        public T remove(int index) {
        	int size = size();
			if(index<0||index>=size){
				throw new IndexOutOfBoundsException();
			}else if(size==1){
				T dato = inicio.getDato();
				inicio = null;
				return dato;
			}
			else if(index == size-1){
				Nodo crawler = inicio;
				for(int i = 0; i < index-1; i++){
					crawler = crawler.getSiguiente();
				}
				Nodo sig = crawler.getSiguiente();
				T dato = (T)sig.getDato();
				sig = null;
				crawler.setSiguiente(null);
				return dato;
			}
			else if(index == 0){
				T dato = inicio.getDato();
				inicio = inicio.getSiguiente();
				return dato;
			}
			else{
				Nodo crawler = inicio;
				for(int i = 0; i < index-1; i++){
					crawler = crawler.getSiguiente();
				}
				Nodo rem = crawler.getSiguiente();
				crawler.setSiguiente(rem.getSiguiente());
				T dato = (T)rem.getDato();
				rem = null;
				return dato;
			}
		}

		//Irvin Uriel Mundo Rivera
        @Override
        public int indexOf(Object o) {
		int index=0;
		Nodo crawler= inicio;
		while(crawler!=null){
			if(crawler.getDato()==o){
				return index;
			}else{
				crawler=crawler.getSiguiente();
			}
		}
		return -1;
	}

        @Override
        public boolean add(T e) {
                //Unchecked

                if(isEmpty()){
                	inicio = new Nodo(e);
                	return true;
                }

            	Nodo crawler = inicio;
            	while(crawler.getSiguiente()!=null){
            		crawler = crawler.getSiguiente();
            	}
            	crawler.setSiguiente(new Nodo(e));

                return true;
        }

        @Override
        public void addFirst(T e) {
                // TODO Auto-generated method stub
				if (isEmpty()) {
					inicio = new Nodo(e);
				} else {
					Nodo nuevo = new Nodo(e);
					nuevo.setSiguiente(inicio);
					inicio = nuevo;
				}

        }

        //TODO
        @Override
        public void addLast(T e) {
                if(isEmpty()){
                	inicio = new Nodo(e);
                } else{
                	Nodo crawler = inicio;
            		while(crawler.getSiguiente()!=null){
            			crawler = crawler.getSiguiente();
            		}
            		crawler.setSiguiente(new Nodo(e));
                }
        }

        @Override
        public String toString(){
                String salida = "";
				Nodo crawler = inicio;
				while (crawler != null) {
					salida += crawler.getDato() + " : ";
					crawler = crawler.getSiguiente();
				}
                return salida;
        }

        //David Alexis Zarate Trujillo
        @Override
        public boolean removeFirstOccurrence(Object o) {
		Nodo b=new Nodo(o);
		Nodo crawler=inicio;
		int i=0;
		while(crawler!=null||crawler.getDato()==b.getDato()){
			i++;
		}
			remove(i);
				return false;
	}

        @Override
        public T removeLast() {
			if(isEmpty()){
				return null;
			}else{
				Nodo<T> aux1=inicio, aux2=null;
				while(aux1.getSiguiente() != null){
					aux2=aux1;
					aux1=aux1.getSiguiente();
				}
				aux2.setSiguiente(null);
				return aux2.getDato();
			}
    }

        @Override
        public T removeFirst() {
			if(isEmpty()){
				return null;
			}else{
				//Nodo<T> aux1=inicio;
				inicio=inicio.getSiguiente();
				return inicio.getDato();
			}
        }

        @Override
        public Iterator<T> iterator() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public Object[] toArray() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public <T> T[] toArray(T[] a) {
                // TODO Auto-generated method stub
                return null;
        }

 		//TODO

        //David Alexis Zarate Trujillo
        @Override
        public boolean remove(Object o) {
		removeFirstOccurrence(o);
		return false;
		}

        @Override
        public boolean containsAll(Collection<?> c) {
                // TODO Auto-generated method stub
                return false;
        }

        //TODO
        @Override
        public boolean addAll(Collection<? extends T> c) {
                // TODO Auto-generated method stub
                return false;
        }

        //TODO
        @Override
        public boolean addAll(int index, Collection<? extends T> c) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean removeAll(Collection<?> c) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean retainAll(Collection<?> c) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public void clear() {
                // TODO Auto-generated method stub

        }

        @Override
        public int lastIndexOf(Object o) {
                // TODO Auto-generated method stub
                return 0;
        }

        @Override
        public ListIterator<T> listIterator() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public ListIterator<T> listIterator(int index) {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public List<T> subList(int fromIndex, int toIndex) {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public boolean offerFirst(T e) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean offerLast(T e) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public T pollFirst() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T pollLast() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T getFirst() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T getLast() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T peekFirst() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T peekLast() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public boolean removeLastOccurrence(Object o) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean offer(T e) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public T remove() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T poll() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T element() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T peek() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public void push(T e) {
                // TODO Auto-generated method stub

        }

        @Override
        public T pop() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public Iterator<T> descendingIterator() {
                // TODO Auto-generated method stub
                return null;
        }

        //Alejandra Cuellar Gonzalez
        //Ethan Avila Hernandez


    }