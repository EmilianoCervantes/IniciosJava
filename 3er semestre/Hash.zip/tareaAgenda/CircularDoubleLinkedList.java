import java.util.Collection;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.*;


public class CircularDoubleLinkedList<T> implements List<T>, Deque<T> {
	//CircularDoubleLinkedList<Integer> lista= new CircularDoubleLinkedList();

        private Nodo<T> inicio;
        private Nodo<T> fin;

        public CircularDoubleLinkedList(){
            fin = inicio = null;
        }


/*****************PRACTICA:  01************************/

           @Override
       		public T get(int index) {
				if(index < 0 || index >= size()){
 					throw new IndexOutOfBoundsException();
 				} return get (index, inicio);
 			}

 			private T get(int index, Nodo n){
 				if (index==0){
 					return (T)n.getDato();
 				}else{
 					return get(index-1, n.getSiguiente());
 				}
 			}


        @Override
		public T set(int index, T element){
      		return (!isEmpty() && index < size() && index>=0) ? set(inicio, index, element) : null;
		}

		private T set(Nodo nodo, int index, T element){
   			if(nodo.getSiguiente() != inicio && index > 0){
       			return set(nodo.getSiguiente(), index-1, element);
    		}else{
        		T d = (T)nodo.getDato();
        		nodo.setDato(element);
       			return d;
    		}
		}

		public void quickSort(){
			quickSort(0);
		}

		private void quickSort(int buscar){
			//int buscar=0;
			for(int i=buscar;i<size();i++){
				T pivot=get(i);
				int storeIndex= i+1;
				for(int j=storeIndex;j<size();j++){
					T temp2=get(j);
					if(((Comparable)pivot).compareTo(temp2)>0){

						set(i,set(j,get(storeIndex)));
						set(storeIndex,set(i,pivot));
						storeIndex++;
					}
				}
				set(i,set(storeIndex-1,get(i)));
				buscar++;
			}
		}

        public void selectionSort(){
			int buscar=0;
			for(int i=buscar;i<size()-1;i++){
				T min = get(buscar);
				int posicion=-1;
				for(int j=i+1;j<size();j++){
					T temp2=get(j);
					if(((Comparable)min).compareTo(temp2)>0){
						min=temp2;
						posicion=j;
					}
				}
				if(get(i)!=min){
					set(posicion,set(i,min));
				}
				buscar++;
			}

        }

        public void insertionSort(){
			int buscar=0;
			for(int i=0;i<size();i++){
				int posicion=i;
				T temp=get(i);
				for(int j=i+1;j<size();j++){
					int posicion2=j;
					T temp2=get(j);
					if(((Comparable)temp).compareTo(temp2)>0){
						T aux=get(i);
						set(posicion,temp2);
						set(posicion2,aux);
					}
				}
			}
        }

/*********************************************************/



        @Override
        public int size() {
            return size(inicio);
        }

        private int size(Nodo<T> nodo){
            if(isEmpty()){
                return 0;
            }else{
                if(nodo.getSiguiente() != inicio){
                    return 1 + size(nodo.getSiguiente());
                }else{
                    return 1;
                }
            }
        }


        @Override
        public void addFirst(T e) {
                // TODO Auto-generated method stub
            if(isEmpty()){
                inicio = fin  = new Nodo(e);
                inicio.setSiguiente(inicio);
                inicio.setAnterior(inicio);
            }else{
                Nodo<T> nuevo = new Nodo(e); //1
                nuevo.setSiguiente(inicio); //2
                nuevo.setAnterior(fin);//3
                fin.setSiguiente(nuevo); //4
                inicio.setAnterior(nuevo); //5
                inicio = nuevo;
            }

        }

        @Override
        public void addLast(T e) {
                // TODO Auto-generated method stub
             if(isEmpty()){
                addFirst(e);
            }else{
                Nodo<T> nuevo = new Nodo(e);
                nuevo.setAnterior(fin);
                nuevo.setSiguiente(inicio);
                inicio.setAnterior(nuevo);
                fin.setSiguiente(nuevo);
                fin = nuevo;
            }
        }


        @Override
        public boolean isEmpty() {
                // TODO Auto-generated method stub
                return inicio == null&& fin==null;
        }

        @Override
       public String toString(){
            return toString(inicio);
		}

       private String toString(Nodo<T> nodo){
			String salida = "";
			if(isEmpty()){
              return "";
            }else if(nodo.getSiguiente() != inicio){
              return salida + " : " + nodo.getDato() + toString(nodo.getSiguiente());
            }else{
              return salida += " : " + fin.getDato();
            }
          }

/*********************************************************/

        @Override
		public int lastIndexOf(Object o) {
                // TODO Auto-generated method stub
                return lastIndexOf(size()-1,o,fin);
        }
        private int lastIndexOf(int pos,Object o,Nodo element){
            if(!isEmpty()){
                return 0;
            }else{

                if(((Comparable)o).compareTo(element.getDato())==0){
                    return pos;
                }else{
                    return lastIndexOf(pos-1,o,element.getAnterior());
                }
            }
        }


        @Override
        public boolean contains(Object o) {
                // TODO Auto-generated method stub
			return contains(size()-1, o, fin);
        }

        private boolean contains(int index, Object o, Nodo nodo){
			if(index < 0){
				return false;
			}else{
				if(((Comparable)o).compareTo(nodo.getDato())==0){
					return true;
                }else{
					return contains(index-1, o, nodo.getAnterior());
				}
			}
        }

        @Override
		public int indexOf(Object o) {
			T dato=(T)o;
 			int a=0;
 			return indexOfRecursivo(dato,inicio,a);
 		}

 		private int indexOfRecursivo(T dato, Nodo<T> aux,int pos){
 			if(aux==null){
 				throw new NullPointerException();
 			}else{
 				if(((Comparable)aux.getDato()).compareTo(dato)==0){
 					return pos;
				}else if(((Comparable)dato).compareTo(inicio.getDato())!=0 && aux.getSiguiente()==inicio){
 					return -1;
 				}else{
 					return indexOfRecursivo(dato,aux.getSiguiente(),pos+1);
 				}
 			}
 		}

        @Override
		public Object[] toArray() {
			if (!isEmpty()) {
				Object[] o = new Object[size()];
				return toArray(size()-1, o, fin);
			}
			return null;
     	}

     private Object[] toArray(int index, Object[] o, Nodo<T> nodo) {
		if (index < 0) {
			return o;
		}else {
			o[index] = nodo.getDato();
     		return toArray(index-1, o, nodo.getAnterior());
     	}
     }

	public T removeMiddle(){
		T dato;
		dato=removeMiddle(inicio,0);
		return dato;
 	}

 	public T removeMiddle(Nodo<T> nodo, int i){
		if(isEmpty()){
			return null;
		}else if(size()/2!=i){
			return removeMiddle(nodo.getSiguiente(),i+1);
		}else{
			Nodo <T> aux=nodo.getAnterior();
			T r=(T)nodo.getDato();
			nodo.setAnterior(nodo.getSiguiente());
			nodo.setSiguiente(aux);
			return r;
		}
	}

	public T getMiddle(){
		return getMiddle(inicio,fin);
	}

	private T getMiddle(Nodo<T> inicio, Nodo<T>fin){
		if(isEmpty()){
                return null;
		}else{
			if((size()%2)!=0){
				if(inicio!=fin){
					return getMiddle(inicio.getSiguiente(),fin.getAnterior());
				}else{
					return inicio.getDato();
				}
			}else{
				if(inicio.getSiguiente()!=fin){
					return getMiddle(inicio.getSiguiente(),fin.getAnterior());
				}else{
					return inicio.getDato();
				}
			}
		}
	}


	public void addMiddle(T e){
		addMiddle(e, inicio,0);
	}

	private void addMiddle(T nuevo, Nodo<T> nodo, int mitad){
		int conteo = size();
		if(isEmpty()){
 			addFirst(nuevo);
 		}else if(mitad!=conteo/2){
 			addMiddle(nuevo, nodo.getSiguiente(),mitad+1);
		}else{
			Nodo<T> n = new Nodo(nuevo);
			Nodo<T> aux1 = null;
			Nodo<T> aux2 = null;
			n.setSiguiente(nodo.getSiguiente());
			n.setAnterior(nodo.getAnterior());
			aux1=nodo.getAnterior();
			aux2=nodo.getSiguiente();
			aux1.setSiguiente(n);
			aux2.setAnterior(n);
		}
 	}



	public int ocurrencias(T e){
		Nodo<T> nodo = new Nodo(e);
		nodo=inicio;
		return ocurrencias(e, nodo);
	}

	private int ocurrencias(T e, Nodo<T> nodo){
		if(isEmpty()){
			return 0;
 		}else{
 			if(nodo.getSiguiente() !=inicio){
 				if(e == nodo.getDato()){
 					return 1 + ocurrencias(e, nodo.getSiguiente());
 				}
 			}
 		}
 		return 0;
	}

	@Override
 	public List<T> subList(int fromIndex, int toIndex) {
 		return subList(fromIndex, toIndex, new CircularDoubleLinkedList());
 	}

 	private List<T> subList(int fromIndex, int toIndex, CircularDoubleLinkedList<T> lista){
 		lista.addFirst(get(fromIndex));
 		if(fromIndex != toIndex){
			return subList(fromIndex + 1, toIndex, lista);
		}else{
			return lista;
		}
 	}

        @Override
        public Iterator<T> iterator() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public <T> T[] toArray(T[] a) {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public boolean add(T e) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean remove(Object o) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean containsAll(Collection<?> c) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean addAll(Collection<? extends T> c) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean addAll(int index, Collection<? extends T> c) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean removeAll(Collection<?> c) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean retainAll(Collection<?> c) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public void clear() {
                // TODO Auto-generated method stub
               inicio = fin = null;
        }


        @Override
        public void add(int index, T element) {//no es recursivo
                // TODO Auto-generated method stub
        	if(isEmpty()){
				inicio= new Nodo(element);
			}else if(index==0){
				addFirst(element);
			}else{
				Nodo<T> crawler = inicio;
				for(int i=0;i<index-1;i++){
					crawler= crawler.getSiguiente();
				}
				Nodo nuevo = new Nodo(element);
				Nodo siguienteCrawler= crawler.getSiguiente();
				nuevo.setSiguiente(siguienteCrawler);
				nuevo.setAnterior(crawler);
				crawler.setSiguiente(nuevo);
				siguienteCrawler.setAnterior(nuevo);
			}
        }



        @Override
		public T remove(int index){
			return remove(index,0,inicio);
		}

        public T remove(int index, int pos, Nodo<T> nodo) {

        	if(isEmpty()){
				return null;
			}else{
				if(pos==index){
					Nodo anterior= nodo.getAnterior();
					Nodo siguiente= nodo.getSiguiente();
					anterior.setSiguiente(siguiente);
					siguiente.setAnterior(anterior);
				}else{
					remove(index,pos+1,nodo.getSiguiente());
				}
			}
			T dato= (T) nodo.getDato();
			return dato;
        }

        @Override
        public ListIterator<T> listIterator() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public ListIterator<T> listIterator(int index) {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public boolean offerFirst(T e) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean offerLast(T e) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public T removeFirst() {
            return null;

        }

        @Override
        public T removeLast() {
                // TODO Auto-generated method stub

                return null;
        }

        @Override
        public T pollFirst() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T pollLast() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T getFirst() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T getLast() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T peekFirst() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T peekLast() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public boolean removeFirstOccurrence(Object o) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean removeLastOccurrence(Object o) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public boolean offer(T e) {
                // TODO Auto-generated method stub
                return false;
        }

        @Override
        public T remove() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T poll() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T element() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public T peek() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public void push(T e) {
                // TODO Auto-generated method stub

        }

        @Override
        public T pop() {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public Iterator<T> descendingIterator() {
                // TODO Auto-generated method stub
                return null;
        }

               public T getTemporal(int index) {
                if(inicio != null){
                    Nodo<T> aux = inicio;
                int y = 0;
                if (index < 0 || index > size() - 1) {
                    throw new IndexOutOfBoundsException("TE PASASTE DE LO QUE REALMENTE TIENES D=");
                }
                while (y < index) {
                    y++;
                    aux = aux.getSiguiente();
                }
                return aux.getDato();
                }else{
                    return null;
                }
    }


    }