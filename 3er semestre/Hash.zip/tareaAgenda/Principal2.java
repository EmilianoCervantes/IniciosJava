import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class Principal2{
	public static HashTable<Persona, CircularDoubleLinkedList<Persona>> contactos = new HashTable(5);

	public static void main(String[]args){
		JFrame frame= new JFrame("Ventana");
		frame.setSize(700,600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

		frame.setLayout(new GridLayout(2,2));

		JPanel izquierdaArriba = new JPanel();
		JPanel izquierdaAbajo = new JPanel();
		JPanel derechaArriba = new JPanel();
		JPanel derechaAbajo = new JPanel();
		frame.add(izquierdaArriba);
		frame.add(derechaArriba);
		frame.add(izquierdaAbajo);
		frame.add(derechaAbajo);

		JSeparator sep= new JSeparator(SwingConstants.HORIZONTAL);
		sep.setBackground(Color.blue);

		izquierdaArriba.setLayout(new GridLayout(5,0));

		JButton agregar= new JButton("Agregar");
			izquierdaArriba.add(agregar);
			//izquierda.add(sep);
		JButton buscar= new JButton("Buscar");
			izquierdaArriba.add(buscar);
			//izquierda.add(sep);
		JButton borrar= new JButton("Borrar");
			izquierdaArriba.add(borrar);
		JButton modificar= new JButton("Modificar");
			izquierdaArriba.add(modificar);
		JButton mostrar= new JButton("Mostrar todo");
			izquierdaArriba.add(mostrar);


		izquierdaAbajo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		izquierdaAbajo.setLayout(new BoxLayout(izquierdaAbajo, BoxLayout.Y_AXIS));

		izquierdaAbajo.add(new JLabel("Nombre"));
		JTextField nombreT = new JTextField();
			izquierdaAbajo.add(nombreT);

		izquierdaAbajo.add(new JLabel("Apellido"));
		JTextField apellidoT = new JTextField();
			izquierdaAbajo.add(apellidoT);

		izquierdaAbajo.add(new JLabel("Direccion"));
		JTextField direccionT = new JTextField();
			izquierdaAbajo.add(direccionT);

		izquierdaAbajo.add(new JLabel("Telefono"));
		JTextField telefonoT = new JTextField();
			izquierdaAbajo.add(telefonoT);

		derechaArriba.add(new JLabel("Funcion Hash"));
			String[] op = {"Nombre", "Apellido", "Direccion", "Telefono"};
			JComboBox opciones = new JComboBox(op);
				derechaArriba.add(opciones);
			JButton seleccionH = new JButton("Ok");
        		derechaArriba.add(seleccionH);
        	DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        	JComboBox agregados = new JComboBox(modelo);
        		derechaArriba.add(agregados);
        	JButton datos = new JButton("Mostrar en cuadro");
        		derechaArriba.add(datos);

        JLabel todo= new JLabel("");
		derechaArriba.add(todo);

		derechaAbajo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		derechaAbajo.setLayout(new BoxLayout(derechaAbajo, BoxLayout.Y_AXIS));

		derechaAbajo.add(new JLabel("Nombre Editado"));
		JTextField nombreE = new JTextField();
			derechaAbajo.add(nombreE);

		derechaAbajo.add(new JLabel("Apellido Editado"));
		JTextField apellidoE = new JTextField();
			derechaAbajo.add(apellidoE);

		derechaAbajo.add(new JLabel("Direccion Editado"));
		JTextField direccionE = new JTextField();
			derechaAbajo.add(direccionE);

		derechaAbajo.add(new JLabel("Telefono Editado"));
		JTextField telefonoE = new JTextField();
			derechaAbajo.add(telefonoE);


        agregar.addActionListener(new ActionListener(){//ya
            public void actionPerformed(ActionEvent e){
                String nombre = nombreT.getText();
                String apellido = apellidoT.getText();
                String direccion = direccionT.getText();
                String telefono = telefonoT.getText();

				CircularDoubleLinkedList<Persona> lista= new CircularDoubleLinkedList();
					Persona nuevo= new Persona(nombre,apellido,direccion,telefono);
					lista.addLast(nuevo);

					contactos.put(nuevo,lista);

                actualizar(agregados,modelo);

            }
        });

        buscar.addActionListener(new ActionListener(){//ya
            public void actionPerformed(ActionEvent e){
				SimpleList<Persona> llaves= contactos.keys();
				for(int i=0;i<llaves.size();i++){
					Persona actual= new Persona(llaves.get(i).getNombre(),llaves.get(i).getApellido(),llaves.get(i).getDireccion(),llaves.get(i).getTelefono());
					if(actual.getNombre().equals(nombreT.getText().toString())){
						JOptionPane.showMessageDialog(frame, "Encontrado");
						nombreE.setText(actual.getNombre());
						apellidoE.setText(actual.getApellido());
						direccionE.setText(actual.getDireccion());
						telefonoE.setText(actual.getTelefono());
					}else if(actual.getApellido().equals(apellidoT.getText().toString())){
						JOptionPane.showMessageDialog(frame, "Encontrado");
						nombreE.setText(actual.getNombre());
						apellidoE.setText(actual.getApellido());
						direccionE.setText(actual.getDireccion());
						telefonoE.setText(actual.getTelefono());
					}else{
						JOptionPane.showMessageDialog(frame, "No Encontrado");
					}
				}
            }
        });

        borrar.addActionListener(new ActionListener(){//ya
            public void actionPerformed(ActionEvent e){
				SimpleList<Persona> llaves= contactos.keys();
				for(int i=0;i<llaves.size();i++){
					Persona actual= new Persona(llaves.get(i).getNombre(),llaves.get(i).getApellido(),llaves.get(i).getDireccion(),llaves.get(i).getTelefono());
					if(actual.getNombre().equals(agregados.getSelectedItem().toString())){
						contactos.eliminar(actual);
						actualizar(agregados,modelo);
						break;
					}
				}
            }
        });


		datos.addActionListener(new ActionListener(){//ya
			public void actionPerformed(ActionEvent e){
				SimpleList<Persona> llaves =  contactos.keys();
				for(int i = 0; i < llaves.size(); i++){
					Persona actual= new Persona(llaves.get(i).getNombre(),llaves.get(i).getApellido(),llaves.get(i).getDireccion(),llaves.get(i).getTelefono());
					if(actual.getNombre().equals(agregados.getSelectedItem().toString())){
						nombreE.setText(actual.getNombre());
						apellidoE.setText(actual.getApellido());
						direccionE.setText(actual.getDireccion());
						telefonoE.setText(actual.getTelefono());
						break;
					}
				}
			}
		});

        modificar.addActionListener(new ActionListener(){//ya
            public void actionPerformed(ActionEvent e){

				SimpleList<Persona> llaves= contactos.keys();
				for(int i=0;i<llaves.size();i++){
					Persona actual= new Persona(llaves.get(i).getNombre(),llaves.get(i).getApellido(),llaves.get(i).getDireccion(),llaves.get(i).getTelefono());
					if(actual.getNombre().equals(agregados.getSelectedItem().toString())){
						actual.setNombre(nombreT.getText().toString());
						actual.setApellido(apellidoE.getText());
						actual.setDireccion(direccionE.getText());
						actual.setTelefono(telefonoE.getText());
						break;
					}
				}
				actualizar(agregados,modelo);
            }
        });

        mostrar.addActionListener(new ActionListener(){//ya
            public void actionPerformed(ActionEvent e){

				todo.setText(contactos.toString());
            }
        });

        seleccionH.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){

			switch(opciones.getSelectedItem().toString()){
                    case "Nombre":
                        Persona.hashFunction = 1;
                        break;
                    case "Apellido":
                        Persona.hashFunction = 2;
                        break;
                    case "Direccion":
                        Persona.hashFunction = 3;
                        break;
                    case "Telefono":
                        Persona.hashFunction = 4;
                        break;
                }
            }
        });

	}

	public static void actualizar(JComboBox agregados,DefaultComboBoxModel modelo){
		modelo.removeAllElements();
		SimpleList<Persona> llaves = contactos.keys();
		for(int i = 0; i < llaves.size(); i++){
			Persona actual= new Persona(llaves.get(i).getNombre(),llaves.get(i).getApellido(),llaves.get(i).getDireccion(),llaves.get(i).getTelefono());
			if(contactos.get(llaves.get(i)) != null){
				modelo.addElement(contactos.get(llaves.get(i)));
			}
		}
		agregados.setModel(modelo);
	}
}